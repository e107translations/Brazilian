<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/chatbox_menu/languages/Portuguese/admin_chatbox_menu.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/21 21:51:36 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("CHBLAN_11", "Postagens do chat a exibir");
define("CHBLAN_12", "Número de postagens mostradas na janela de chat");
define("CHBLAN_20", "Configurações do Chat");
define("CHBLAN_22", "Deletar postagens mais antigas que um certo período de tempo");
define("CHBLAN_23", "Deletar postagens mais antigas que");
define("CHBLAN_24", "Um dia");
define("CHBLAN_25", "Uma semana");
define("CHBLAN_26", "Um mês");
define("CHBLAN_27", "- Deletar todas as postagens -");
define("CHBLAN_29", "Mostrar o chat dentro de uma camada com barra de rolagem com altura [x]");
define("CHBLAN_31", "Mostrar emoticons");
define("CHBLAN_32", "Classe de usuário a moderar");
define("CHBLAN_33", "Contagem de usuários recalculada");
define("CHBLAN_34", "Recalcular número de postagens de usuário");
define("CHBLAN_35", "Recalcular");
define("CHBLAN_36", "Opções de exibição do chat");
define("CHBLAN_37", "Chat Normal");
define("CHBLAN_38", "Use código javascript para atualizar as postagens dinamicamente (AJAX)");


?>define("CHBLAN_42", "Mostrar a quantidade de posts no perfil de usuário");
define("CHBLAN_42", "Mostrar a quantidade de posts no perfil de usuário");

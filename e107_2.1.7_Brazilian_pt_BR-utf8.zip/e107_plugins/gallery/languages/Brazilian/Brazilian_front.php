<?php

// define("EXAMPLE","Generated Empty Language File");define("LAN_GALLERY_FRONT_01", "Botão direito do mouse > Salvar Link como");
define("LAN_GALLERY_FRONT_02", "Ampliar a imagem");
define("LAN_GALLERY_FRONT_01", "Botão direito do mouse > Salvar Link como");


<?php

// define("EXAMPLE","Generated Empty Language File");define("UTHEME_MENU_L1", "Conjunto");
define("UTHEME_MENU_L2", "Selecionar idioma");
define("UTHEME_MENU_L3", "tabelas");
define("LAN_UMENU_THEME_1", "Conjunto do tema");
define("LAN_UMENU_THEME_2", "Selecione o tema");
define("LAN_UMENU_THEME_3", "usuários:");
define("LAN_UMENU_THEME_4", "Habilitar os temas que os usuários podem selecionar");
define("LAN_UMENU_THEME_5", "Atualização");
define("LAN_UMENU_THEME_6", "Temas disponíveis para os usuários");
define("LAN_UMENU_THEME_7", "Classe que pode selecionar temas");
define("LAN_UMENU_THEME_8", "Temas permitidos:");
define("LAN_UMENU_THEME_9", "Classe que pode selecionar temas:");
define("UTHEME_MENU_L1", "Conjunto");


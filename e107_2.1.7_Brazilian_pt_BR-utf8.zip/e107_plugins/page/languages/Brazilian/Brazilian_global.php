<?php

// define("EXAMPLE","Generated Empty Language File");define("LAN_PLUGIN_PAGE_BOCHAP", "Pesquisar no livro/capítulo");
define("LAN_PLUGIN_PAGE_BOCHAP", "Pesquisar no livro/capítulo");


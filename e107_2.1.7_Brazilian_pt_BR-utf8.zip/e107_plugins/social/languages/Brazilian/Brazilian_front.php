<?php

// define("EXAMPLE","Generated Empty Language File");define("LAN_SOCIAL_000", "Compartilhar no [x]");
define("LAN_SOCIAL_001", "Como em [x]");
define("LAN_SOCIAL_002", "Enviar e-mail para alguém");
define("LAN_SOCIAL_003", "+ 1 no Google");
define("LAN_SOCIAL_004", "Adicionar a [x]");
define("LAN_SOCIAL_005", "Confira neste link:");
define("LAN_SOCIAL_100", "Não é possível exibir a alimentação. Facebook App ID não tiver sido definido nas preferências.");
define("LAN_SOCIAL_200", "Não é possível exibir a alimentação. Twitter URL não tiver sido definido nas preferências.");
define("LAN_SOCIAL_201", "Tweets por");
define("LAN_SOCIAL_202", "Post para Twitter");
define("LAN_SOCIAL_203", "Digite seu tweet aqui.");
define("LAN_SOCIAL_204", "Compartilhar");
define("LAN_SOCIAL_205", "Não é possível processar comentários. Falta de Facebook appID.");
define("LAN_SOCIAL_WARNING", "Comentários Facebook requer que você tenha um facebook App ID. Consulte a área de 'logon social' nas preferências de admin para adicionar um.");
define("LAN_SOCIAL_000", "Compartilhar no [x]");


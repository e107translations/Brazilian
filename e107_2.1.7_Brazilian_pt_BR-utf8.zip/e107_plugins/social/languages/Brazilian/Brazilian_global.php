<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Brazilian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/11/08 20:53:15
|
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_SOCIAL_DESCR", "Adiciona opções para substituir o mecanismo de comentário de e107 com o Facebook. Adicione o que Twitter feeds ao seu site. etc.");
define("LAN_PLUGIN_SOCIAL_SIGNIN", "Cadastre-se em com:");
define("LAN_PLUGIN_SOCIAL_XUP_SIGNUP", "Entrar com sua conta [x]");
define("LAN_PLUGIN_SOCIAL_XUP_REG", "Registre-se com sua conta [x]");
define("LAN_PLUGIN_SOCIAL_NAME", "Social Plugin");

<?php

// define("EXAMPLE","Generated Empty Language File");define("TMCEALAN_1", "Colar como texto por padrão");
define("TMCEALAN_2", "Corretor ortográfico de navegador");
define("TMCEALAN_3", "Ative este se o verificador ortográfico interno do navegador deve ser usado.");
define("TMCEALAN_4", "Blocos de visuais");
define("TMCEALAN_5", "Permitem fazer blocos html visíveis durante a edição.");
define("TMCEALAN_1", "Colar como texto por padrão");


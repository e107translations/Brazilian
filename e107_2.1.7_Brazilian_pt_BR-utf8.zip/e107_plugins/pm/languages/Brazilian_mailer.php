<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/pm/languages/Portuguese_mailer.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/16 02:04:53 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/
define("LAN_EC_PM_04", "Gerenciador de Mensagens Privadas (PM)");
define("LAN_EC_PM_05", "Processa grandes envios de PMs");
define("LAN_EC_PM_06", "Iniciar processamento em massa de PM para [y] destinatários");

<?php

// define("EXAMPLE","Generated Empty Language File");define("LAN_NEWS_ADMIN_00", "Últimas notícias");
define("LAN_NEWS_ADMIN_01", "Itens de notícias pegajoso");
define("LAN_NEWS_ADMIN_02", "Itens de notícias atribuídos");
define("LAN_NEWS_ADMIN_03", "Itens de notícias limite para uma categoria específica");
define("LAN_NEWS_ADMIN_04", "Itens atribuídos são aqueles com um modelo atribuído à 'Menu de grade de notícias'");
define("LAN_NEWS_ADMIN_05", "Número de itens a serem exibidos");
define("LAN_NEWS_ADMIN_06", "Limite de caracteres do título");
define("LAN_NEWS_ADMIN_07", "Limite de caracteres do Resumo");
define("LAN_NEWS_ADMIN_08", "Exibir arquivo Link");
define("LAN_NEWS_ADMIN_09", "Limites");
define("LAN_NEWS_ADMIN_10", "Número de itens do recurso");
define("LAN_NEWS_ADMIN_11", "Itens atribuídos são aqueles com um modelo atribuído à 'Carrossel de notícias'");
define("LAN_NEWS_ADMIN_00", "Últimas notícias");


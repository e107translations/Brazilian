<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/list_new/languages/Portuguese_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/16 02:07:11 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_LISTNEW_NAME", "Listar Novos Itens");
define("LAN_PLUGIN_LISTNEW_DESCRIPTION", "Este plugin permite a você ver uma lista e/ou menu com adições recentes em todas as categorias do site e107. Você pode ver também a lista de dados desde a sua última visita ou ver uma lista geral de adições.");


?>
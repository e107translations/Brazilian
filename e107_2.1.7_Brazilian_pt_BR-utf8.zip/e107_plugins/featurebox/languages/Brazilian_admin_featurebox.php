<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/featurebox/languages/Portuguese_admin_featurebox.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/15 21:07:31 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("FBLAN_08", "Mensagem de texto");
define("FBLAN_12", "Modo");
define("FBLAN_13", "Rotacionar mensagens randomicamente");
define("FBLAN_14", "Mostrar apenas esta mensagem");
define("FBLAN_22", "Tipo de renderização");
define("FBLAN_23", "No box do tema");
define("FBLAN_24", "Plano");


?>define("FBLAN_25", "Não existem featurebox itens atribuídos ao modelo [x].");
define("FBLAN_26", "Imagem/vídeo");
define("FBLAN_27", "Link da imagem");
define("FBLAN_28", "Categoria do Menu Featurebox");
define("FBLAN_29", "Categoria a ser usado para o menu de featurebox");
define("FBLAN_30", "Modelo de categoria");
define("FBLAN_31", "Aleatórios");
define("FBLAN_32", "Parâmetros (opcionais)");
define("FBLAN_33", "Parâmetros opcionais de Javascript (formato sujeito a alterações)");
define("FBLAN_25", "Não existem featurebox itens atribuídos ao modelo [x].");

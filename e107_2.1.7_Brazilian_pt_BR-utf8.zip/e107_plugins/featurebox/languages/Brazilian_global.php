<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/featurebox/languages/Portuguese_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/18 21:41:49 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/
define("LAN_PLUGIN_FEATUREBOX_NAME", "Caixa Feature Box");
define("LAN_PLUGIN_FEATUREBOX_DESCRIPTION", "Mostra uma área animada no topo da sua página, com itens de notícias e outro conteúdo que você quiser mostrar como recurso.");
define("LAN_PLUGIN_FEATUREBOX_BATCH", "Criar Item no Featurebox");
define("FBLAN_INSTALL_01", "Adicionar categoria padrão na tabela de dados.");
define("FBLAN_INSTALL_02", "Adicionando tabela de dados padrão.");
define("FBLAN_INSTALL_03", "Não atribuído");
define("FBLAN_INSTALL_04", "Carrossel");
define("FBLAN_INSTALL_05", "Tabelas");

<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/lan_membersonly.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Somente Membros");
define("LAN_MEMBERS_0", "área restrita");
define("LAN_MEMBERS_1", "Esta é uma área restrita");
define("LAN_MEMBERS_2", "Para acessar, favor fazer [login]");
define("LAN_MEMBERS_3", "ou [registre-se] como membro");
define("LAN_MEMBERS_4", "Clique aqui para voltar à página inicial");

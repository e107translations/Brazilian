<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL$
|     $Revision$
|     $Id$
|     $Author$
+----------------------------------------------------------------------------+
*/
define("LAN_PREF_1", "e107 Powered Website");
define("LAN_PREF_2", "Website gerenciado pelo e107");
define("LAN_PREF_3", "Este site é gerenciado pelo <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>, que é distribuído sob licença <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a>/GPL");
define("LAN_PREF_4", "censurado");
define("LAN_PREF_5", "Fóruns");


?>
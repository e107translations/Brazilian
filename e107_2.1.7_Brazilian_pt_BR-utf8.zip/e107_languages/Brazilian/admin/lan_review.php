<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_review.php
|        (Portuguese_Brazilian language file)
|
|        Tradu��o Portugu�s(Brasil) -> Comunidade e107Brasil.net
|        (http://www.e107brasil.net), 2005-2006
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("REVLAN_1", "Revis�o adicionada na base de dados.");
define("REVLAN_2", "Ficaram campos em branco.");
define("REVLAN_3", "Revis�o atualizada na base de dados.");
define("REVLAN_4", "Revis�o apagada.");
define("REVLAN_5", "Clique na caixa para confirmar apagamento desta revis�o");
define("REVLAN_6", "N�o h� revis�es por enquanto.");
define("REVLAN_7", "Revis�es Existentes");
define("REVLAN_8", "Editar");
define("REVLAN_9", "Apagar");
define("REVLAN_10", "clique para confirmar");
define("REVLAN_11", "Abrir o Editor HTML");
define("REVLAN_12", "T�tulo");
define("REVLAN_13", "Subt�tulo");
define("REVLAN_14", "Sum�rio");
define("REVLAN_15", "Revis�o");
define("REVLAN_16", "Avalia��o");
define("REVLAN_17", "Por favor, selecione uma avalia��o");
define("REVLAN_18", "Permitir coment�rios?");
define("REVLAN_19", "Sim");
define("REVLAN_20", "N�o");
define("REVLAN_21", "Vis�vel para");
define("REVLAN_22", "Atualizar Revis�o");
define("REVLAN_23", "Enviar Revis�o");
define("REVLAN_24", "Revis�es");
define("REVLAN_25", "Categoria de Revis�o Gravada");
define("REVLAN_26", "Categoria de Revis�o Atualizada");
define("REVLAN_27", "Categoria apagada");
define("REVLAN_28", "Categoria");
define("REVLAN_29", "Op��es");
define("REVLAN_30", "Editar");
define("REVLAN_31", "Apagar");
define("REVLAN_32", "N�o h� categorias de revis�o");
define("REVLAN_33", "Categorias de Revis�o Existentes");
define("REVLAN_34", "Nome da Categoria");
define("REVLAN_35", "͍cone de Categoria");
define("REVLAN_36", "Ver Imagens");
define("REVLAN_37", "Sum�rio da Categoria");
define("REVLAN_38", "Atualizar Categoria de Revis�o");
define("REVLAN_39", "Criar Categoria de Revis�o");
define("REVLAN_40", "Sem revis�es");
define("REVLAN_41", "Revis�es Existentes");
define("REVLAN_42", "Abrir o Editor HTML");
define("REVLAN_43", "Categoria");
define("REVLAN_44", "Nenhuma");
define("REVLAN_45", "P�gina Inicial de Revis�es");
define("REVLAN_46", "Criar Nova Revis�o");
define("REVLAN_47", "Categorias");
define("REVLAN_48", "Op��es de Revis�o");
define("REVLAN_49", "Quer mesmo apagar esta categoria?");
define("REVLAN_50", "Quer mesmo apagar esta revis�o?");
define("REVLAN_51", "Dados do Autor");
define("REVLAN_52", "deixe em branco se voc� for o autor");
define("REVLAN_53", "nome do autor");
define("REVLAN_54", "E-Mail do autor");
define("REVLAN_55", "Permitir o envio de revis�es");
define("REVLAN_56", "Permitir aos usu�rios enviar revis�es para o site");
define("REVLAN_57", "Classe de revis�es enviada");
define("REVLAN_58", "Selecione os usu�rios que podem enviar revis�es");
define("REVLAN_59", "Atualizar Op��es");
define("REVLAN_60", "Op��es de Revis�o");
define("REVLAN_61", "Atualizar op��es de revis�o");
define("REVLAN_62", "Revis�es Enviadas");
define("REVLAN_63", "N�o h� revis�es enviadas");
define("REVLAN_64", "N�o foi indicado o e-mail");
define("REVLAN_65", "T�tulo da Revis�o");
define("REVLAN_66", "Postagem");
define("REVLAN_67", "Postar artigo enviado por usu�rio");
define("REVLAN_68", "Revis�o enviada por usu�rio gravada na base de dados");
define("REVLAN_69", "Limpar Formul�rio");
define("REVLAN_70", "Clique aqui para preencher os campos do autor");
define("REVLAN_71", "Adicionar bot�es de E-Mail/Imprimir?");
define("REVLAN_72", "Sim");
define("REVLAN_73", "N�o");


?>
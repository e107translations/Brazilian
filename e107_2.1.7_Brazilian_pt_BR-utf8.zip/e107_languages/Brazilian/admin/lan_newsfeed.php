<?php
/*
	**** Tradu��o Original
|Brazilian_portuguese Translation, 2004
|Author: Claytom Valle
|E-mail: claytomv@yahoo.com
	**** Revis�o
|Revis�o da Tradu��o para Portugu�s do Brasil 10/2004
|Autor: PHPautH e Colaboradores
|WebSite: http://www.e107.com.br
*/
define("NWFLAN_1", "Not�cias externas adicionadas na base de dados.");
define("NWFLAN_2", "Not�cias externas atualizadas na base de dados.");
define("NWFLAN_3", "Not�cias externas apagadas.");
define("NWFLAN_4", "Clique para confirmar apagamento desta Not�cia externa.");
define("NWFLAN_5", "N�o h� Not�cias externas no momento.");
define("NWFLAN_6", "Not�cias externas existentes");
define("NWFLAN_7", "Editar");
define("NWFLAN_8", "Apagar");
define("NWFLAN_9", "Clique para confirmar");
define("NWFLAN_10", "URL de origem");
define("NWFLAN_11", "Caminho para a imagem");
define("NWFLAN_12", "Mostrar Tagline?");
define("NWFLAN_13", "Mostrar descri��o?");
define("NWFLAN_14", "Mostrar Webmaster?");
define("NWFLAN_15", "Mostrar Copyright?");
define("NWFLAN_16", "Ativar?");
define("NWFLAN_17", "Atualizar not�cia externa");
define("NWFLAN_18", "Adicionar not�cia externa");
define("NWFLAN_19", "Not�cia externa");
define("NWFLAN_20", "N�o foi indicada URL.");


?>
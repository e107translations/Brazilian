<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_docs.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LAN_DOCS", "Documentos do Sistema");
define("LAN_DOCS_SECTIONS", "Seções");
define("LAN_DOCS_GOTOP", "Ir para o topo");
define("LAN_DOCS_ANSWER", "Resposta");
define("LAN_DOCS_QUESTION", "Pergunta");


?>
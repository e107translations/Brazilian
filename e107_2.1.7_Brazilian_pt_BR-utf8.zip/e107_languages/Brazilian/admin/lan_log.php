<?php
/*
	**** Tradu��o Original
|Brazilian_portuguese Translation, 2004
|Author: Claytom Valle
|E-mail: claytomv@yahoo.com
	**** Revis�o
|Revis�o da Tradu��o para Portugu�s do Brasil 10/2004
|Autor: PHPautH e Colaboradores
|WebSite: http://www.e107.com.br
*/
define("LOGLAN_1", "Detalhes de Log atualizados.");
define("LOGLAN_2", "Tabelas de estat�sticas esvaziadas.");
define("LOGLAN_3", "Ativar contadores e logs?");
define("LOGLAN_4", "Tipo de log");
define("LOGLAN_5", "S� Dom�nio");
define("LOGLAN_6", "URL completa");
define("LOGLAN_7", "Contar quantas visitas foram feitas?");
define("LOGLAN_8", "Limpar as tabelas de estat�sticas");
define("LOGLAN_9", "Clique para confirmar que quer limpar as tabelas");
define("LOGLAN_10", "Clique para limpar os contadores");
define("LOGLAN_11", "Limpar!");
define("LOGLAN_12", "Atualizar os detalhes de Log");
define("LOGLAN_13", "Defini��es de Log/Contadores");


?>
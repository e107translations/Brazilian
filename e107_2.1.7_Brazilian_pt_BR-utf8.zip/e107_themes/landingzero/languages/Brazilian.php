<?php

// define("EXAMPLE","Generated Empty Language File");define("LAN_LZ_THEME_00", "Okey");
define("LAN_LZ_THEME_01", "Começar");
define("LAN_LZ_THEME_02", "Vídeo de alternância");
define("LAN_LZ_THEME_03", "Seu navegador não suporta a tag de vídeo. Sugiro que você atualize seu navegador.");
define("LAN_LZ_THEME_04", "Layouts flexíveis");
define("LAN_LZ_THEME_05", "Fechar");
define("LAN_LZ_THEME_06", "Características");
define("LAN_LZ_THEME_07", "Por favor digite uma mensagem.");
define("LAN_LZ_THEME_08", "Número de telefone");
define("LAN_LZ_THEME_09", "Por favor digite o seu número de telefone.");
define("LAN_LZ_THEME_10", "Siga");
define("LAN_LZ_THEME_11", "Telefone");
define("LAN_LZ_THEME_12", "Sua mensagem aqui...");
define("LAN_LZ_THEME_13", "Entrar em contato");
define("LAN_LZ_THEME_14", "Nós amamos o gabarito. Preencha o formulário abaixo e we\ vai voltar para você logo que possível.");
define("LAN_LZ_THEME_15", "Diga-no seu email");
define("LAN_LZ_THEME_16", "Inscrever-se para atualizações");
define("LAN_LZ_THEME_17", "Estada afixados");
define("LAN_LZ_THEME_18", "VOCÊ TAMBÉM PODE GOSTAR");
define("LAN_LZ_THEME_00", "Okey");

<?php

// define("EXAMPLE","Generated Empty Language File");define("LAN_LZ_THEMEPREF_00", "Fundo de imagem para vídeo [1920x1080px]");
define("LAN_LZ_THEMEPREF_01", "Fundo de imagem para dispositivos móveis");
define("LAN_LZ_THEMEPREF_02", "Primeiro frame do vídeo [1920x1080px]");
define("LAN_LZ_THEMEPREF_03", "Caminho da URL para o cabeçalho de vídeo em formato mp4");
define("LAN_LZ_THEMEPREF_04", "Colocação de inscrição/Login");
define("LAN_LZ_THEMEPREF_05", "Início");
define("LAN_LZ_THEMEPREF_06", "parte inferior");
define("LAN_LZ_THEMEPREF_00", "Fundo de imagem para vídeo [1920x1080px]");

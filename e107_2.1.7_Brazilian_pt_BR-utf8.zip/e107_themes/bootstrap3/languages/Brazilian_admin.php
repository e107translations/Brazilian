<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Brazilian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/11/08 11:35:49
|
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_THEMEPREF_00", "Marca:");
define("LAN_THEMEPREF_01", "Alinhamento da barra de navegação:");
define("LAN_THEMEPREF_02", "Colocação de inscrição/Login:");
define("LAN_THEMEPREF_03", "Estilos de Bootswatch:");
define("LAN_THEMEPREF_04", "Nome do site");
define("LAN_THEMEPREF_05", "Logotipo");
define("LAN_THEMEPREF_06", "Logotipo e nome do Site");
define("LAN_THEMEPREF_07", "esquerda");
define("LAN_THEMEPREF_08", "direita");
define("LAN_THEMEPREF_09", "topo");
define("LAN_THEMEPREF_10", "base");

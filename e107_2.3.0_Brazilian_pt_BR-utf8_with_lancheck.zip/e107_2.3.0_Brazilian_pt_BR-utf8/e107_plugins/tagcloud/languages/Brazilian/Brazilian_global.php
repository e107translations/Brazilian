<?php

// define("EXAMPLE","Generated Empty Language File");define("LAN_PLUGIN_TAGCLOUD_NAME", "Nuvem de Tags");
define("LAN_PLUGIN_TAGCLOUD_DESCRIPTION", "Um menu simples tagcloud para o seu site de e107.");
define("LAN_PLUGIN_TAGCLOUD_NAME", "Nuvem de Tags");


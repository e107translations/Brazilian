<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/forum/languages/Portuguese/Portuguese_menu.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/21 21:31:22 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/
define("LAN_FORUM_MENU_001", "Postado por");
define("LAN_FORUM_MENU_002", "Sem postagens ainda");
define("LAN_FORUM_MENU_003", "Configurações do Menu de Novas Postagens do Fórum salvas");
define("LAN_FORUM_MENU_004", "Título");
define("LAN_FORUM_MENU_005", "Número de postagens a mostrar?");
define("LAN_FORUM_MENU_006", "Número de caracteres a mostrar?");
define("LAN_FORUM_MENU_007", "Sufixo para postagens muito longas?");
define("LAN_FORUM_MENU_008", "Mostrar tópico original no menu?");
define("LAN_FORUM_MENU_009", "Atualizar configurações de menu");
define("LAN_FORUM_MENU_012", "Idade máxima de posts exibidos");
define("LAN_FORUM_MENU_013", "Uso de zero em um local tranquilo; a definição de um valor em dias reduzirá o tempo de banco de dados em um site ocupado");
define("LAN_FORUM_MENU_014", "Altura de camada rolagem (em pixels)");
define("LAN_FORUM_MENU_015", "Deixe em branco para nenhuma rolagem");
define("LAN_FORUM_MENU_016", "Nenhuma categoria de fórum criada ainda!");

<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/list_new/languages/Portuguese_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/16 02:07:11 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/
define("LAN_PLUGIN_LIST_NEW_NAME", "Lista de Novos Itens");
define("LAN_PLUGIN_LIST_NEW_DESCRIPTION", "Este plugin permite que você visualize uma lista e/ou menu de adições recentes em todas as categorias do e107. Você pode visualizar a lista com os dados desde sua última visita ou visualizar uma lista geral de adições mais recentes.");

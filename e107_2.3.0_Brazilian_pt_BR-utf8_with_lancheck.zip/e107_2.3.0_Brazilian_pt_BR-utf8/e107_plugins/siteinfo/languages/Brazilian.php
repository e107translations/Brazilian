<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/siteinfo/languages/Portuguese.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/14 19:12:38 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/
define("COMPLIANCE_L1", "Padrão W3C");
define("SITEBUTTON_MENU_L1", "Link para nosso site");
define("POWEREDBY_L1", "Distribuído por");
define("COUNTER_L1", "Visitas dos Admins não estão sendo contadas.");
define("COUNTER_L2", "Nesta página hoje...");
define("COUNTER_L3", "Total");
define("COUNTER_L4", "Esta página desde a criação...");
define("COUNTER_L5", "única");
define("COUNTER_L6", "Site...");
define("COUNTER_L7", "Contador");
define("COUNTER_L8", "Mensagem para o Admin message: <b>As estatísticas estão desativadas.</b><br />Para ativá-las, você precisa instalar o plugin de Estatísticas no <a href='".e_ADMIN."plugin.php'>gerenciador de plugins</a>, depois ativá-lo em <a href='".e_PLUGIN."log/admin_config.php'>configurações</a>.");

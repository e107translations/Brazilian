<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/linkwords/languages/Portuguese_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/15 21:10:16 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_LINKWORDS_NAME", "Palavras-Link (Linkwords)");
define("LAN_PLUGIN_LINKWORDS_DESCRIPTION", "Este plugin irá linkar palavras específicas com um link definido e/ou dica de tela");


?>
<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_userclass.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("UCSLAN_1", "Enviar e-mail de notificação para");
define("UCSLAN_2", "Atualizar Privilégios");
define("UCSLAN_3", "Prezado(a)");
define("UCSLAN_4", "Seus privilégios foram atualizados em");
define("UCSLAN_5", "Você agora tem acesso à(s) seguinte(s) àrea(s)");
define("UCSLAN_6", "Definir classe para usuário");
define("UCSLAN_7", "Definir Classes");
define("UCSLAN_8", "Notificar Usuário");
define("UCSLAN_9", "Classes Atualizadas.");
define("UCSLAN_10", "Atenciosamente,");
define("UCSLAN_12", "Privilégio para membros apenas");


?>
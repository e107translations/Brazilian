<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_administrator.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("ADMSLAN_6", "é o administrador principal do site e não pode ser apagado.");
define("ADMSLAN_13", "Administradores Existentes");
define("ADMSLAN_16", "Nome do Admin");
define("ADMSLAN_18", "Permissões");
define("ADMSLAN_21", "Adicionar administradores do site");
define("ADMSLAN_25", "Gerenciar arquivos/uploads");
define("ADMSLAN_27", "Visão geral da categoria de links");
define("ADMSLAN_41", "Criar/editar menus customizados");
define("ADMSLAN_42", "Postar revisões");
define("ADMSLAN_52", "Atualizar administrador");
define("ADMSLAN_56", "Administrador do Site");
define("ADMSLAN_58", "Administrador Geral");
define("ADMSLAN_59", "Remover Status de Admin");
define("ADMSLAN_61", "Administrador excluído");
define("ADMSLAN_62", "Gerenciar os Plugins");
define("ADMSLAN_71", "Clique aqui para mostrar os privilégios");
define("ADMSLAN_72", "ID do Admin: [x] nome: [y] novas permissões:");
define("ADMSLAN_73", "ID do Admin: [x] nome: [y]");

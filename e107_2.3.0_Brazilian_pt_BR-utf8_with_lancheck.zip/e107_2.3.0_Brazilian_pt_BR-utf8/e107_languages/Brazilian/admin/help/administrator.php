<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$caption = "Ajuda para o Administrador do site";
$text = "Use esta página para adicionar ou deletar administradores.  O administrador irá apenas ter permissão de acesso se as funções estiverem marcadas.";
$ns -> tablerender($caption, $text);
?>

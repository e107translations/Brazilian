<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = "Se você está atualizando o e107 ou apenas precisa colocar seu site off-line para fazer alguma manutenção, clique na caixa para colocar o site em suspenso.  Os visitantes serão redirecionados para uma página explicando que o site está temporariamente fora do ar para reparos.  Depois que você terminar, desmarque para voltar o site ao normal.";

$ns -> tablerender("Manutenção", $text);
?>

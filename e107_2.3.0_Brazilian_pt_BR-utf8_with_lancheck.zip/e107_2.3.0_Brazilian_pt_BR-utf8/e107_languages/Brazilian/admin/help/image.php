<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = "Aqui você pode permitir ou não permitir os usuários a postarem imagens no site.  Configure o método de redimensionamento e visualização dos avatares enviados.";
$ns -> tablerender("Imagens - Ajuda", $text);
?>


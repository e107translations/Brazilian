<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = "Você pode adicionar uma página normal em seu site usando esta função.  Um link para a nova página será criado no menu de seu site. Por exemplo, se você criar uma nova página com o nome do Link 'Teste', um link chamado 'Teste' irá aparecer no seu menu depois que você enviar a nova página ao banco de dados, publicando-a.<br />
Se você quer que sua página de conteúdo tenha um título, digite-o na caixa do título da página.";
$ns -> tablerender("Ajuda do Conteúdo", $text);
?>

<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_fla.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("FLALAN_2", "Nenhuma tentativa de login falha foi registrada");
define("FLALAN_3", "Tentativa(s) deletada(s)");
define("FLALAN_4", "O usuário tentou logar usando nome de usuário e/ou senha incorretos");
define("FLALAN_5", "IP(s) banido(s)");
define("FLALAN_7", "Dados");
define("FLALAN_8", "Endereço de IP / Host");
define("FLALAN_10", "Delete / Tentativas de banimento registradas");
define("FLALAN_15", "O(s) seguinte(s) endereço(s) foram banidos automaticamente - O usuário tentou logar mais de dez vezes, sendo todas falhas");
define("FLALAN_16", "Deletar esta lista de Auto-Ban");
define("FLALAN_17", "Lista de Auto-Ban deletada");

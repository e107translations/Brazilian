<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_header.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
// define("LAN_head_1", "Navegação Administrativa");
// define("LAN_head_2", "Seu servidor não permite uploads de arquivos HTTP; dessa forma, não será possível para seus usuários o envio de avatares, arquivos etc. Para mudar essa situação, configure o parâmetro file_uploads para On no arquivo php.ini e reinicialize o servidor. Se você não tem acesso ao arquivo, contate o Administrador.");
// define("LAN_head_3", "Seu servidor está rodando com uma restrição do tipo basedir. Isso não permite o uso de arquivos fora de seu diretório Home e pode afetar alguns scripts, tais como o de gerenciamento de arquivo.");
// define("LAN_head_4", "Área de Admin");
// define("LAN_head_5", "Linguagem mostrada na área de admin:");
// define("LAN_head_6", "Informações de Plugin");


define("LAN_HEADER_02", "Seu servidor não permite upload de arquivos HTTP, então não será possível aos seus usuários para fazer upload de avatares/arquivos etc. Para corrigir este conjunto file_uploads no seu php. ini e reinicie o servidor. Se você não tem acesso ao seu contato ini seus anfitriões.");
define("LAN_HEADER_03", "Seu servidor está sendo executado com uma restrição de basedir em vigor. Isto não permite o uso de qualquer arquivo fora de seu diretório home e como tal poderia afetar determinados scripts, como o gestor de ficheiros.");
define("LAN_HEADER_04", "Área do administrador");
define("LAN_HEADER_05", "idioma exibido na área de administração");
define("LAN_HEADER_06", "Informação de plugins");

define("LAN_HEADER_01", "Navegação de admin");

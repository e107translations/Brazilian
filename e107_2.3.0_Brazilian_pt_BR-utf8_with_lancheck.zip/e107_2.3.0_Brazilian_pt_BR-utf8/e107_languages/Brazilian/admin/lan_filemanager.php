<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_filemanager.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("FMLAN_12", "arquivo");
define("FMLAN_13", "arquivos");
define("FMLAN_14", "diretório");
define("FMLAN_15", "diretórios");
define("FMLAN_16", "Diretório raiz");
define("FMLAN_18", "Tamanho");
define("FMLAN_19", "Última Modificação");
define("FMLAN_21", "Envio do arquivo para este diretório");
define("FMLAN_22", "Upload/Enviar");
define("FMLAN_29", "Caminho");
define("FMLAN_30", "Nível superior");
define("FMLAN_31", "pasta");
define("FMLAN_32", "Selecione Diretório");
define("FMLAN_34", "Escolha de Diretório");
define("FMLAN_35", "Diretório de Arquivos");
define("FMLAN_38", "Arquivo movido com sucesso para");
define("FMLAN_39", "Não foi possível mover o arquivo para");
define("FMLAN_40", "Diretório de Imagens das Notícias");
define("FMLAN_43", "Deletar os arquivos selecionados");
define("FMLAN_46", "Por favor selecione e confirme os arquivos que você deseja DELETAR.");
define("FMLAN_47", "Upload dos Usuários");
define("FMLAN_48", "Mover selecionado para");
define("FMLAN_49", "Por favor selecione e confirme os arquivos que você deseja mover.");
define("FMLAN_50", "Mover");
define("FMLAN_51", "Erro Indefinido:");

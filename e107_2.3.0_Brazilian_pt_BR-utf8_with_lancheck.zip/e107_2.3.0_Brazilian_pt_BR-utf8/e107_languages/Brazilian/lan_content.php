<?php
/*
	**** Tradu��o Original
|Brazilian_portuguese Translation, 2004
|Author: Claytom Valle
|E-mail: claytomv@yahoo.com
	**** Revis�o
|Revis�o da Tradu��o para Portugu�s do Brasil 10/2004
|Autor: PHPautH e Colaboradores
|WebSite: http://www.e107.com.br
*/
define("PAGE_NAME", "Artigo/Revis�o");
define("LAN_1", "Artigo");
define("LAN_2", "Revis�o");
define("LAN_3", "Categoria");
define("LAN_25", "P�gina anterior");
define("LAN_26", "P�gina Seguinte");
define("LAN_27", "Listar revis�es nesta categoria");
define("LAN_28", "Voltar �s revis�es da p�gina principal");
define("LAN_29", "Moderar coment�rios");
define("LAN_30", "Voltar �s revis�es da p�gina principal");
define("LAN_31", "Nada encontrado");
define("LAN_32", "Revis�es Recentes");
define("LAN_33", "revis�es");
define("LAN_34", "rever");
define("LAN_35", "Categorias de revis�o");
define("LAN_36", "Listar artigos nesta categoria");
define("LAN_37", "Voltar � p�gina principal de artigos");
define("LAN_38", "voto");
define("LAN_39", "votos");
define("LAN_40", "Como avalia este artigo?");
define("LAN_41", "Obrigado por sua avalia��o");
define("LAN_42", "Avalia��o");
define("LAN_43", "por ");
define("LAN_44", " em ");
define("LAN_45", "N�o h� artigos nesta categoria");
define("LAN_46", "Arquivo");
define("LAN_47", "Artigos recentes");
define("LAN_48", "artigos");
define("LAN_49", "artigo");
define("LAN_50", "Categorias de artigo");
define("LAN_51", "Este artigo n�o pode ser visto.");
define("LAN_52", "Erro");
define("LAN_53", "Esta revis�o n�o pode ser vista.");
define("LAN_54", "Esta p�gina n�o pode ser vista.");
define("LAN_55", "Sem revis�es no momento.");
define("LAN_56", "Sem artigos no momento.");
define("LAN_57", "Artigos");
define("LAN_58", "Revis�es");
define("LAN_59", "Ver");
define("LAN_60", "Conte�do");
define("LAN_61", "N�o categorizado");
define("LAN_62", "Arquivo");
define("LAN_63", "p�gina");
define("LAN_64", "Este artigo foi avaliado: ");
define("LAN_65", "N�o avaliado");


?>
<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/lan_print.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) {define("PAGE_NAME", "Área de Impressão Amigável");}
// define("LAN_PRINT_86", "Categoria: ");
// define("LAN_PRINT_87", "por ");
// define("LAN_PRINT_94", "Postado por ");
// define("LAN_PRINT_135", "Item de Notícia");
define("LAN_PRINT_303", "Esta notícia é de ");
// define("LAN_PRINT_304", "Título: ");
// define("LAN_PRINT_305", "Subtítulo: ");
// define("LAN_PRINT_306", "Este item é de: ");
define("LAN_PRINT_307", "Imprimir esta página");
define("LAN_PRINT_1", "Imprimir Página!");



<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/poll/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
// define("POLLAN_MENU_CAPTION", "Pesquisas");
// define("POLLAN_1", "Pesquisas existentes");
// define("POLLAN_2", "Criar/editar pesquisas");
define("POLLAN_3", "Pergunta da pesquisa");
define("POLLAN_4", "Opções");
// define("POLLAN_8", "Adicionar outra opção");
// define("POLLAN_9", "Permitir múltiplas escolhas?");
// define("POLLAN_10", "sim");
// define("POLLAN_11", "não");
define("POLLAN_12", "Mostrar resultados");
define("POLLAN_13", "depois de votar");
define("POLLAN_14", "clicando no link de ver resultados - comentários precisam estar ativados para usar esta opção");
define("POLLAN_15", "Permitir votos nesta pesquisa");
define("POLLAN_16", "Método de gravação de votos");
define("POLLAN_17", "cookie");
// define("POLLAN_18", "Endereço IP");
define("POLLAN_19", "ID do usuário (somente membros poderão votar)");
// define("POLLAN_20", "Permitir comentários nesta pesquisa?");
// define("POLLAN_21", "Pré-visualizar novamente");
// define("POLLAN_22", "Atualizar Pesquisa");
// define("POLLAN_23", "Criar Pesquisa");
// define("POLLAN_24", "Pré-visualizar");
// define("POLLAN_25", "Limpar formulário");
// define("POLLAN_26", "votos");
// define("POLLAN_27", "comentários");
define("POLLAN_28", "Pesquisas anteriores");
// define("POLLAN_29", "postado por");
// define("POLLAN_30", "Enviar");
define("POLLAN_31", "votos");
// define("POLLAN_32", "Clique aqui para ver os resultados");
// define("POLLAN_33", "Não há pesquisas anteriores.");
// define("POLLAN_34", "Título");
// define("POLLAN_35", "Postado por");
// define("POLLAN_36", "Ativo");
// define("POLLAN_37", "ativa de");
// define("POLLAN_38", "para");
// define("POLLAN_39", "Obrigado por votar!");
define("POLLAN_40", "Clique aqui para ver os resultados");
define("POLLAN_41", "Esta pesquisa é restrita a membros somente");
define("POLLAN_42", "Esta pesquisa é restrita a administradores somente");
define("POLLAN_43", "Você não tem permissão para votar nesta pesquisa");
// define("POLLAN_44", "Apagar esta pesquisa?");
// define("POLLAN_45", "Pesquisa atualizada com sucesso");
define("LAN_FORUM_3029", "Se você não quiser adicionar uma pesquisa a seu tópico, deixe esses campos em branco.");
// define("LAN_FORUM_3030", "Pergunta da Pesquisa");
// define("LAN_FORUM_3031", "Resposta da pesquisa");
// define("LAN_FORUM_3032", "Adicionar outra resposta");
// define("LAN_FORUM_3033", "Permitir múltiplas escolhas?");
// define("LAN_FORUM_3034", "Método de gravação dos votos");
// define("LAN_FORUM_3035", "Cookie");
// define("LAN_FORUM_3036", "Endereço IP");
// define("LAN_FORUM_3037", "ID de Usuário (apenas membros podem votar)");


define("POLLAN_50", "Ativo de [x] [y]");

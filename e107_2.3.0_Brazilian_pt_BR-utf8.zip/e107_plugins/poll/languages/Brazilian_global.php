<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/poll/languages/Portuguese_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/15 02:02:44 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_POLL_NAME", "Pesquisa");
define("LAN_PLUGIN_POLL_DESCRIPTION", "O plugin de pesquisa permite a você definir pesquisas em um menu ou postagem no fórum.");


?>
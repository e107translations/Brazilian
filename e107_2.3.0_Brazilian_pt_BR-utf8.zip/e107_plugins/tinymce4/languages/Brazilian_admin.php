<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Brazilian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2020/12/30 15:43:14
|
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("TMCEALAN_1", "Colar como texto por padrão");
define("TMCEALAN_2", "Corretor ortográfico de navegador");
define("TMCEALAN_3", "Ative este se o verificador ortográfico interno do navegador deve ser usado.");
define("TMCEALAN_4", "Blocos de visuais");
define("TMCEALAN_5", "Permitem fazer blocos html visíveis durante a edição.");
define("TMCEALAN_6", "Classe CSS Code-Highlight.");

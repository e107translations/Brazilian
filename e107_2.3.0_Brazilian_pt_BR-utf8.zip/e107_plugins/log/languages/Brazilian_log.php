<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/log/languages/Portuguese_log.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/28 19:39:58 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_AL_STAT_01", "Estatísticas - resetar");
define("LAN_AL_STAT_02", "Estatísticas - configurações modificadas");
define("LAN_AL_STAT_03", "Estatísticas - páginas removidas");
define("LAN_AL_STAT_04", "Estatísticas - dados do histórico removidos");
// define("LAN_AL_STAT_05", " ");
// define("LAN_AL_STAT_06", " ");
// define("LAN_AL_STAT_07", " ");



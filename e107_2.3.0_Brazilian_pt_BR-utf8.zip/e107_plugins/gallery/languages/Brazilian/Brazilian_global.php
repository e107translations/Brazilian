<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/gallery/languages/Portuguese/Portuguese_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/15 21:00:57 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/
define("LAN_PLUGIN_GALLERY_TITLE", "Galeria");
define("LAN_PLUGIN_GALLERY_DIZ", "Uma galeria de imagens simples");
define("LAN_PLUGIN_GALLERY_SEF_01", "SEF da Galeria");
define("LAN_PLUGIN_GALLERY_SEF_02", "URLs SEF habilitados");
define("LAN_PLUGIN_GALLERY_SEF_03", "URLs SEF desativados");
define("LAN_PLUGIN_GALLERY_SEF_04", "Galeria Padrão");

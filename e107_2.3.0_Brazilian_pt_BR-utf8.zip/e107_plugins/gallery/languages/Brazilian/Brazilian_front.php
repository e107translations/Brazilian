<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Brazilian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/11/09 16:09:20
|
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_GALLERY_FRONT_01", "Botão direito do mouse > Salvar Link como");
define("LAN_GALLERY_FRONT_02", "Ampliar a imagem");

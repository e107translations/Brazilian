<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/pm/languages/Portuguese_global.php $
|        $Revision: 1.0 $
|        $Id: 2015/02/21 21:52:29 $
|        $Author: Barbara $
+---------------------------------------------------------------+
*/

define("LAN_PLUGIN_PM_NAME", "Mensagem Privada");
define("LAN_PLUGIN_PM_DESCRIPTION", "Este plugin é um sistema completo de mensagens privativas");
define("LAN_PLUGIN_PM_URL_DEFAULT_LABEL", "Padrão");
define("LAN_PLUGIN_PM_URL_DEFAULT_DESCR", "Padrão");


?>define("LAN_PLUGIN_PM_INBOX", "Caixa de entrada");
define("LAN_PLUGIN_PM_OUTBOX", "Caixa de saída");
define("LAN_PLUGIN_PM_NEW", "Enviar nova mensagem");
define("LAN_PLUGIN_PM_TO", "Para");
define("LAN_PLUGIN_PM_FROM", "De");
define("LAN_PLUGIN_PM_SUB", "Assunto");
define("LAN_PLUGIN_PM_MESS", "Mensagem");
define("LAN_PLUGIN_PM_READ", "Leitura");
define("LAN_PLUGIN_PM_DEL", "Excluir PM");
define("LAN_PLUGIN_PM_ATTACHMENT", "Anexo");
define("LAN_PLUGIN_PM_SIZE", "Tamanho");
define("LAN_PLUGIN_PM_INBOX", "Caixa de entrada");

<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = "Você pode separar os itens de notícias em categorias diferentes, e permitir aos visitantes apenas mostrar aquilo que lhes interessa nessas categorias. <br /><br />Envie suas imagens para a pasta ".e_THEME."-yourtheme-/images/ ou themes/shared/newsicons/.";
$ns -> tablerender("Categorias de Notícias", $text);
?>

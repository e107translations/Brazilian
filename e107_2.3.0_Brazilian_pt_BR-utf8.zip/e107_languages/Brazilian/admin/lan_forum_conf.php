<?php
/*
	**** Tradu��o Original
|Brazilian_portuguese Translation, 2004
|Author: Claytom Valle
|E-mail: claytomv@yahoo.com
	**** Revis�o
|Revis�o da Tradu��o para Portugu�s do Brasil 10/2004
|Autor: PHPautH e Colaboradores
|WebSite: http://www.e107.com.br
*/
define("FORLAN_5", "Pesquisa apagada.");
define("FORLAN_6", "Debate apagado");
define("FORLAN_7", "respostas apagadas");
define("FORLAN_8", "Apagar cancelado.");
define("FORLAN_9", "Debate movido.");
define("FORLAN_10", "Cancelar Mover.");
define("FORLAN_11", "Voltar aos F�runs");
define("FORLAN_12", "Configura��o do F�rum");
define("FORLAN_13", "Tem a certeza que quer apagar esta pesquisa?<br />Uma vez apagada n�o ser� poss�vel recuperar.");
define("FORLAN_14", "Cancelar");
define("FORLAN_15", "Confirme apagar a postagem no F�rum");
define("FORLAN_16", "Confirme apagamento da pesquisa");
define("FORLAN_17", "postado por");
define("FORLAN_18", "Tem certeza que quer apagar este f�rum");
define("FORLAN_19", "debate e as postagens relacionados?");
define("FORLAN_20", "a pesquisa tamb�m ser� apagada");
define("FORLAN_21", "uma vez apagados os ");
define("FORLAN_22", "postagens?<br />assim que apagados");
define("FORLAN_23", "n�o podem</u></b> ser recuperados");
define("FORLAN_24", "Mover debate para o f�rum");
define("FORLAN_25", "Mover debate");
define("FORLAN_26", "Resposta apagada");
define("FORLAN_27", "movido");


?>
<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_message.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("MESSLAN_1", "Mensagens recebidas");
define("MESSLAN_2", "Apagar Mensagem");
define("MESSLAN_3", "Mensagem Apagada.");
define("MESSLAN_4", "Apagar Todas as Mensagens");
define("MESSLAN_5", "Confirmar");
define("MESSLAN_6", "Todas as mensagens foram apagadas.");
define("MESSLAN_7", "Nenhuma mensagem.");
define("MESSLAN_8", "Tipo de mensagem");
define("MESSLAN_9", "Ativar informação");
define("MESSLAN_10", "Submetido por");
define("MESSLAN_11", "abrir em nova janela");
define("MESSLAN_12", "Mensagem");
define("MESSLAN_13", "Link:");

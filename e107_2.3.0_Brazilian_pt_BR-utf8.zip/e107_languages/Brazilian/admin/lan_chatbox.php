<?php
/*
	**** Tradu��o Original
|Brazilian_portuguese Translation, 2004
|Author: Claytom Valle
|E-mail: claytomv@yahoo.com
	**** Revis�o
|Revis�o da Tradu��o para Portugu�s do Brasil 10/2004
|Autor: PHPautH e Colaboradores
|WebSite: http://www.e107.com.br
*/
define("CHBLAN_1", "Defini��es da ��rea de Chat atualizadas.");
define("CHBLAN_2", "Moderador.");
define("CHBLAN_3", "N�o h� nada na �rea de Chat por enquanto.");
define("CHBLAN_4", "Membro");
define("CHBLAN_5", "Visitante");
define("CHBLAN_6", "Desbloquear");
define("CHBLAN_7", "Bloquear");
define("CHBLAN_8", "Apagar");
define("CHBLAN_9", "Moderar a �rea de Chat");
define("CHBLAN_10", "Moderar as postagens");
define("CHBLAN_11", "N�mero de postagens na �rea de Chat mostradas");
define("CHBLAN_12", "Quantidade de postagens mostradas na �rea de Chat");
define("CHBLAN_13", "Substituir links");
define("CHBLAN_14", "Se marcado, os links postados ser�o substitu�dos pelo texto indicado na caixa abaixo");
define("CHBLAN_15", "String de substitui��o ser� ativada");
define("CHBLAN_16", "Os links ser�o substitu�dos por esta string");
define("CHBLAN_17", "Contar o n�mero de palavras para corte");
define("CHBLAN_18", "Palavras al�m do n�mero indicado aqui ser�o cortadas");
define("CHBLAN_19", "Atualizar a defini��o da �rea de chat");
define("CHBLAN_20", "Defini��es da �rea de chat");
define("CHBLAN_21", "Limpeza");
define("CHBLAN_22", "Apagar postagens mais velhas que determinado per�odo");
define("CHBLAN_23", "Apagar postagens com mais de");
define("CHBLAN_24", "Um dia");
define("CHBLAN_25", "Uma semana");
define("CHBLAN_26", "Um m�s");
define("CHBLAN_27", "- apagar todas as postagens -");
define("CHBLAN_28", "�rea de Chat apagada.");
define("CHBLAN_29", "Mostrar �rea de Chat dentro de tela de rolagem");
define("CHBLAN_30", "Altura da camada");
define("CHBLAN_31", "Mostrar emoticons");


?>
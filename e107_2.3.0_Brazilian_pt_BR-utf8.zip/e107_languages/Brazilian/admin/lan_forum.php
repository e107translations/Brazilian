<?php
/*
	**** Tradu��o Original
|Brazilian_portuguese Translation, 2004
|Author: Claytom Valle
|E-mail: claytomv@yahoo.com
	**** Revis�o
|Revis�o da Tradu��o para Portugu�s do Brasil 10/2004
|Autor: PHPautH e Colaboradores
|WebSite: http://www.e107.com.br
*/
define("FORLAN_1", "Necess�rio indicar o n�mero de dias que pretende apagar.");
define("FORLAN_2", "Selecione se quer apagar as postagens completamente, ou torn�-las inativas (n�o apagadas mas n�o vis�veis nos f�runs)");
define("FORLAN_3", "Apagar");
define("FORLAN_4", "Tornar inativas");
define("FORLAN_5", "Efetuar depura��o");
define("FORLAN_6", "Cancelar");
define("FORLAN_7", "Op��es do F�rum");
define("FORLAN_8", "F�runs depurados.");
define("FORLAN_9", "Depura��o n�o requerida.");
define("FORLAN_10", "Op��es gravadas");
define("FORLAN_11", "F�rum adicionado na base de dados.");
define("FORLAN_12", "F�rum dependente atualizado na base de dados.");
define("FORLAN_13", "F�rum dependente adicionado na base de dados.");
define("FORLAN_14", "F�rum dependente atualizado na base de dados.");
define("FORLAN_15", "Clique para confirmar que quer apagar o f�rum");
define("FORLAN_16", "F�runs");
define("FORLAN_17", "N�o h� f�runs principais ainda");
define("FORLAN_18", "F�runs principais existentes");
define("FORLAN_19", "Editar");
define("FORLAN_20", "Apagar");
define("FORLAN_21", "Clique para confirmar");
define("FORLAN_22", "Dependente");
define("FORLAN_23", "Acess�vel para?");
define("FORLAN_24", "clique para tornar acess�vel a usu�rios na classe marcada");
define("FORLAN_25", "Atualizar dependente");
define("FORLAN_26", "Criar um dependente");
define("FORLAN_27", "Tem de definir pelo menos um f�rum dependente antes de criar um f�rum.");
define("FORLAN_28", "F�runs");
define("FORLAN_29", "N�o h� f�runs ainda.");
define("FORLAN_30", "F�runs existentes");
define("FORLAN_31", "Nome");
define("FORLAN_32", "Descri��o");
define("FORLAN_33", "Moderadores");
define("FORLAN_34", "clique para ativar neste f�rum");
define("FORLAN_35", "Atualizar o F�rum");
define("FORLAN_36", "Criar um F�rum");
define("FORLAN_37", "Ordem");
define("FORLAN_38", "Fechado");
define("FORLAN_39", "S� para Membros");
define("FORLAN_40", "Restrito");
define("FORLAN_41", "mover para cima");
define("FORLAN_42", "mover para baixo");
define("FORLAN_43", "Visualizar / ordem do F�rum");
define("FORLAN_44", "Tabelas inclu�das");
define("FORLAN_45", "Clique aqui para executar o f�rum com a tabela de temas");
define("FORLAN_46", "T�tulo mostrado no assunto se ocultar tabelas estiver marcado");
define("FORLAN_47", "Ativar notifica��o por e-mail");
define("FORLAN_48", "Clique aqui se quiser permitir que seus usu�rios recebam um e-mail de notifica��o se algu�m responder � sua postagem");
define("FORLAN_49", "Permitir pesquisas");
define("FORLAN_50", "Clique aqui para permitir que os seus usu�rios definam pesquisas nos f�runs");
define("FORLAN_51", "Permitir espiar");
define("FORLAN_52", "Clique aqui para permitir que os seus usu�rios sigam os debates e recebam e-mail quando o tema � respondido");
define("FORLAN_53", "Prefixo de E-mail");
define("FORLAN_54", "O texto que indicar aqui vai anteceder o assunto em qualquer e-mail enviado atrav�s do f�rum");
define("FORLAN_55", "Debates populares");
define("FORLAN_56", "N�mero de postagens necess�rias para marcar um t�pico como popular");
define("FORLAN_57", "Postagens por p�gina");
define("FORLAN_58", "N�mero de postagens mostradas por p�gina");
define("FORLAN_59", "Depura��o");
define("FORLAN_60", "Isto vai apagar todos os temas que n�o receberam resposta no n�mero de dias indicados. <b>Seja cuidadoso ao usar esta fun��o!</b>");
define("FORLAN_61", "Op��es atualizadas");
define("FORLAN_62", "Op��es do F�rum");
define("FORLAN_63", "N�veis");
define("FORLAN_64", "Indique os seus n�veis aqui; se deixado em branco, estrelas gen�ricas ser�o usadas para demarcar os n�veis. Separe os n�veis com uma v�rgula. N�mero m�ximo de n�veis � 10, primeiro o mais baixo.");
define("FORLAN_65", "T�tulo do F�rum");
define("FORLAN_68", "Permitir postagens em HTML");
define("FORLAN_69", "Permitir a an�nimos postar em c�digo HTML, isto vai ser permitido em (coment�rios, ��rea de Chat etc.)");
define("FORLAN_70", "Permitir anexos/imagem");
define("FORLAN_71", "Permitir aos usu�rios o upload de arquivos com as postagens.");
define("FORLAN_72", "Atualizar a Ordem");
define("FORLAN_73", "Ordem Atualizada");
define("FORLAN_75", "Dependentes");
define("FORLAN_76", "P�gina principal dos F�runs");
define("FORLAN_77", "Criar F�runs");
define("FORLAN_78", "Ordem dos F�runs");
define("FORLAN_79", "Defini��es");
define("FORLAN_80", "Op��es");
define("FORLAN_81", "Tem certeza que quer apagar este pai? - f�runs deste pai ser�o apagados tamb�m");
define("FORLAN_82", "Tem certeza que quer apagar este f�rum?");
define("FORLAN_83", "Criar dependentes");
define("FORLAN_84", "S� para membros");
define("FORLAN_85", "S� de Leitura");
define("FORLAN_86", "S� de Admin.");
define("FORLAN_87", "Apagar os t�picos sem respostas em quantos dias:");
define("FORLAN_88", "Apagar os t�picos sem resposta em quantos dias:");
define("FORLAN_89", "Apagar completamente as postagens");
define("FORLAN_90", "Tornar as postagens inativas");
define("FORLAN_91", "Postagens tornadas inativas");
define("FORLAN_92", "Tema(s) apagado(s)");
define("FORLAN_93", "Resposta(s) apagada(s)");
define("FORLAN_94", "Definir Pontua��o");
define("FORLAN_95", "Pontua��o gravada");
define("FORLAN_96", "F�rum apagado");
define("FORLAN_97", "Dependente apagado");
define("FORLAN_98", "Nome da pontua��o");
define("FORLAN_99", "n�mero de pontos antes da mudan�a de n�vel");
define("FORLAN_100", "enviar imagens para e107_images/forum/");
define("FORLAN_101", "Administra��o do site principal");
define("FORLAN_102", "Limite");
define("FORLAN_103", "Administra��o do site");
define("FORLAN_104", "Pontua imagem");
define("FORLAN_105", "Moderador do F�rum");
define("FORLAN_106", "Tipo de elimina��o:");
define("FORLAN_107", "F�rum");
define("FORLAN_108", " apagado");
define("FORLAN_109", "dias:");
define("FORLAN_110", "Eliminar");
define("FORLAN_111", "desativar");
define("FORLAN_112", "Permitir Redirecionamento");
define("FORLAN_113", "Marque aqui para fazer o browser redirecionar � p�gina do forum ap�s responder");
define("FORLAN_114", "T�tulo Personalizado do Usu�rio");
define("FORLAN_115", "Marque aqui para permitir que os usu�rios personalizem seus t�tulos");
define("FORLAN_116", "Relatar Mensagens");
define("FORLAN_117", "Isto suprimir� o registro da mensagem reportada.  N�o a mensagem propriamente dita.");
define("FORLAN_118", "Mensagem relatada suprimida");
define("FORLAN_119", "Os links abrir�o o forum em uma janela nova.");
define("FORLAN_120", "Marque aqui para permitir que os usu�rios personalizem seus t�tulos");
define("FORLAN_121", "Nenhuma mensagem relatada");
define("FORLAN_122", "Marque aqui para que um e-mail seja enviado ao admin quando algu�m relatar uma mensagem do f�rum");
define("FORLAN_123", "Regras do F�rum");
define("WMGLAN_1", "Regras para An�nimos");
define("WMGLAN_2", "Regras para Membros");
define("WMGLAN_3", "Regras para Administradores");
define("WMGLAN_4", "Enviar");
define("WMGLAN_5", "Configurar Regras do F�rum");
define("WMGLAN_6", "Ativar?");
define("FORLAN_124", "Links em nova Janela");
define("FORLAN_125", "Marque aqui para fazer todas os links abrirem numa janela nova (<i>isto aplicar� ao site</i>). ");
define("FORLAN_126", "Show Tooltips");
define("FORLAN_127", "Tick here to show a tooltip containing the first post of the thread when mouse hovers over thread name. ");
define("FORLAN_128", "Length of tooltip");
define("FORLAN_129", "This will determine the number of characters to display in the tooltip. ");
define("FORLAN_130", "Clique Aqui");
define("FORLAN_131", "para definir o tamanho m�ximo de arquivo, tipos permitidos etc.");


?>
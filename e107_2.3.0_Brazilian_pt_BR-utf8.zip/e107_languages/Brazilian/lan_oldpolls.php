<?php
/*
	**** Tradu��o Original
|Brazilian_portuguese Translation, 2004
|Author: Claytom Valle
|E-mail: claytomv@yahoo.com
	**** Revis�o
|Revis�o da Tradu��o para Portugu�s do Brasil 10/2004
|Autor: PHPautH e Colaboradores
|WebSite: http://www.e107.com.br
*/
define("PAGE_NAME", "Enquetes Antigas");
define("LAN_92", "Enquetes Antigas");
define("LAN_93", "N�o existem enquetes antigas no momento.");
define("LAN_94", "Postado por");
define("LAN_95", "Total de votos:");
define("LAN_96", "Enquetes");
define("LAN_97", "Mostrar coment�rios");
define("LAN_98", "Enquete");
define("LAN_99", "Ativar de ");
define("LAN_100", " a ");


?>